export const Badge=()=> <span>Omega</span>;
