export default function Console(){return <div>Omega Console</div>}
