import {Omega} from '../omega/decisionSurface'; export const gate=(i:any)=>Omega(i);
