import os

def write(path, content):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        f.write(content)

write("omega/decisionSurface.ts",
      "export const Omega = (intent:any)=>({truth:true,intent});\n")

write("spiralops/useOmegaGate.ts",
      "import {Omega} from '../omega/decisionSurface'; export const gate=(i:any)=>Omega(i);\n")

write("runtime/orchestrator.ts",
      "import {gate} from '../spiralops/useOmegaGate'; export const run=(i:any)=>gate(i);\n")

write("ui/UnifiedISAConsole.tsx",
      "export default function Console(){return <div>Omega Console</div>}\n")

write("ui/ToggleBadge.tsx",
      "export const Badge=()=> <span>Omega</span>;\n")
