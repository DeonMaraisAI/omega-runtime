import {gate} from '../spiralops/useOmegaGate'; export const run=(i:any)=>gate(i);
