export const Omega = (intent:any)=>({truth:true,intent});
