import os, hashlib

EXPECTED_HASH = "594f05c1fabbefac8a98acf4fa4918d7a5ba931905ce8e6f69ff940b56d28af4"

def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        h.update(f.read())
    return h.hexdigest()

file_hashes = {
  "rebuild.py": "60ac0ed1b77fef31bd10f302b844f8f7ae3cc10aa2e346c8d5625c6603ff9e9a",
  "omega/decisionSurface.ts": "345b9afd4926028be144e7b9af659f3e2c606f305272bbaa62d142fd82e23580",
  "spiralops/useOmegaGate.ts": "272d88c3befdc6ffbf3e8b006eabfd3ed78ccfebd09372133a37dc5fe0e5899b",
  "runtime/orchestrator.ts": "26f03fe129d9b5173a911ea3211b06cc60731dee35d8dd414f4fe44237b84c5c",
  "ui/UnifiedISAConsole.tsx": "04f8c93333d6e1125f418ff37d8367ec57a99b85a37b8e5fe5c0fd12df4d88f7",
  "ui/ToggleBadge.tsx": "102004953ee45ada86e4b0743f6fed7dfee0147a748f6bf47fd222da9a64d4c1"
}

current = {}
for path in file_hashes:
    if not os.path.exists(path):
        print("MISSING:", path)
        exit(1)
    current[path] = sha256_file(path)

concat = "".join([current[k] for k in sorted(current)])
calc = hashlib.sha256(concat.encode()).hexdigest()

if calc == EXPECTED_HASH:
    print("REPRODUCIBLE VALID")
else:
    print("REPRODUCIBLE INVALID")
